library(psych)
library(ggplot2)
library(readxl)
library(Moments)
file <- "dinodane.xlsx"
dino <- readxl::read_excel(file)
head(dino)
dino <-dinodane

statystyki <- describe(dino$`Stopy zwrotu`)
print(statystyki, digits = 6)

statystyki_dziennie <- tapply(dino$`Stopy zwrotu`, dino$`Dzień tygodnia`, describe)

# Wyświetlenie uzyskanych statystyk
print(statystyki_dziennie, digits =6)

# Wyświetlenie wyników
statystyki
ggplot(dino, aes(x =`Stopy zwrotu`)) +
  geom_histogram(binwidth = 0.01, fill = "blue", color = "black", alpha = 0.7) +
  labs(title = "Histogram Stóp Zwrotu", x = "Stopy Zwrotu", y = "Częstość") +
  theme_minimal()

dino$`Dzień tygodnia` <- factor(dino$`Dzień tygodnia`, levels = c("poniedziałek", "wtorek", "środa", "czwartek", "piątek"))

# Stworzenie podzbioru danych bez NA w kolumnie "Dzień tygodnia"
subset_dino <- dino[!is.na(dino$`Dzień tygodnia`), ]

# Wykres pudełkowy tylko dla dni od poniedziałku do piątku
ggplot(subset_dino, aes(x = `Dzień tygodnia`, y = `Stopy zwrotu`)) +
  geom_boxplot(fill = "lightblue", color = "black", alpha = 0.7) +
  labs(title = "Wykres Pudełkowy Stóp Zwrotu", x = "Dzień Tygodnia", y = "Stopy Zwrotu") +
  theme_minimal()

ggplot(dino, aes(x = "", y = `Stopy zwrotu`)) +
  geom_boxplot(fill = "lightblue", color = "black", alpha = 0.7) +
  labs(title = "Wykres Pudełkowy Stóp Zwrotu", x = NULL, y = "Stopy Zwrotu") +
  theme_minimal()



##  TEST kOŁOGOMOGROWA
## a) dla stóp zwrotu
stopy_zwrotu <- dino$`Stopy zwrotu`
# Usuń wartości NA i duplikaty
stopy_zwrotu1 <- na.omit(unique(stopy_zwrotu))

(mean_s_z <- mean(stopy_zwrotu, na.rm=TRUE))
(sd_s_z <- sd(stopy_zwrotu, na.rm=TRUE))
ks.test(stopy_zwrotu1, "pnorm", mean_s_z, sd_s_z) ## brak podstaw do odrzucenia
## b) dla stóp zwrotu zamk otw
## c) dla stóp zwrotu otw zamk

## TEST SHAPIRO
shapiro.test(stopy_zwrotu)

## TEST CHI KWADRAT 

(mean_s_z <- mean(stopy_zwrotu))
sd_s_z  <- sd (stopy_zwrotu)


# kwantyle 
q1 <- qnorm (0.1 , mean = mean_s_z , sd = sd_s_z )
q2 <-qnorm (0.2 , mean = mean_s_z , sd = sd_s_z )
q3 <-qnorm (0.3 , mean = mean_s_z , sd = sd_s_z )
q4 <-qnorm (0.4 , mean = mean_s_z , sd = sd_s_z )
q5 <-qnorm (0.5 , mean = mean_s_z , sd = sd_s_z )
q6 <-qnorm (0.6 , mean = mean_s_z , sd = sd_s_z )
q7 <-qnorm (0.7 , mean = mean_s_z , sd = sd_s_z )
q8 <-qnorm (0.8 , mean = mean_s_z , sd = sd_s_z )
q9 <-qnorm (0.9 , mean = mean_s_z , sd = sd_s_z )
q10 <- qnorm( 1, mean = mean_s_z , sd = sd_s_z )

# podział na klasy

k1 <- stopy_zwrotu[stopy_zwrotu < q1]
k2 <- stopy_zwrotu[stopy_zwrotu < q2 & stopy_zwrotu > q1]
k3 <- stopy_zwrotu[stopy_zwrotu < q3 & stopy_zwrotu > q2]
k4 <- stopy_zwrotu[stopy_zwrotu < q4 & stopy_zwrotu > q3]
k5 <- stopy_zwrotu[stopy_zwrotu < q5 & stopy_zwrotu > q4]
k6 <- stopy_zwrotu[stopy_zwrotu < q6 & stopy_zwrotu > q5]
k7 <- stopy_zwrotu[stopy_zwrotu < q7 & stopy_zwrotu > q6]
k8 <- stopy_zwrotu[stopy_zwrotu < q8 & stopy_zwrotu > q7]
k9 <- stopy_zwrotu[stopy_zwrotu < q9 & stopy_zwrotu > q8]
k10 <- stopy_zwrotu[stopy_zwrotu < q10 & stopy_zwrotu > q9]


liczebnosc <- c(length(k1) , length(k2), length(k3), length(k4), length(k5), length(k6), length(k7), length(k8), length(k9), length(k10))
print(liczebnosc)
help ( "chisq.test")

prob <- rep ( 0.1, 10)

# UWAGA! pamietać o tym że porównujemy do prawdopodobieństwa 
chisq.test( liczebnosc, p = prob)





